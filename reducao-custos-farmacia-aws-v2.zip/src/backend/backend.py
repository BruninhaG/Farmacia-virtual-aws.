import csv

def calcular_faturamento():
    total = 0
    with open('../../data/produtos_farmacia.csv', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            total += float(row['Preco_Venda']) * int(row['Estoque'])
    return total

if __name__ == '__main__':
    print('Faturamento estimado:', calcular_faturamento())
