# Redução dos Custos em Farmácias com AWS

## Visão Geral
Dashboard de farmácia fictícia com dados reais, cálculo de faturamento e foco
em otimização de custos usando serviços AWS.

## Funcionalidades
- Visualização de produtos
- Cálculo de faturamento e lucro
- Dados estruturados em planilha
- Arquitetura AWS focada em redução de custos
